#requires -Version 3.0
# Validate that src/ui.xaml is well-formed XML and can be loaded by WPF XamlReader.
# csc.exe embeds ui.xaml as a plain resource without parsing it, so a compile can
# succeed even when the XAML is broken. Run this script (STA) after every UI edit:
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File scripts\check-xaml.ps1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
$root = Split-Path -Parent $PSScriptRoot
$xaml = Join-Path $root 'src\ui.xaml'
[xml]$doc = Get-Content -LiteralPath $xaml -Raw -Encoding UTF8
$reader = New-Object System.Xml.XmlNodeReader $doc
$window = [System.Windows.Markup.XamlReader]::Load($reader)
"parsed title={0} width={1} height={2}" -f $window.Title, $window.Width, $window.Height
