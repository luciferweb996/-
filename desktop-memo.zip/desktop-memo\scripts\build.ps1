#requires -Version 3.0
# Build DesktopMemo.exe from source using the .NET Framework C# compiler (csc.exe).
# No Visual Studio / dotnet SDK needed -- only .NET Framework 4.x (ships with Windows).
# Pure ASCII on purpose: Windows PowerShell 5.1 reads .ps1 as GBK, so all Chinese
# strings are built from Unicode code points (see below).
$ErrorActionPreference = 'Stop'

$root   = Split-Path -Parent $PSScriptRoot
$src    = Join-Path $root 'src'
$assets = Join-Path $root 'assets'
$bin    = Join-Path $root 'bin'
if (-not (Test-Path -LiteralPath $bin)) { New-Item -ItemType Directory -Path $bin | Out-Null }

# ' desktop memo.exe' chinese stem from code points: 桌面备忘录
$stem = ''
foreach ($c in 0x684C,0x9762,0x5907,0x5FD8,0x5F55) { $stem += [char]$c }
$name = $stem + '.exe'
$out  = Join-Path $bin $name

# Locate the compiler + reference assemblies from the CLR this script runs on.
$fw  = [System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory().TrimEnd('\')
$csc = Join-Path $fw 'csc.exe'
$wpf = Join-Path $fw 'WPF'
if (-not (Test-Path -LiteralPath $csc)) { throw "csc.exe not found at $csc (.NET Framework 4.x required)" }

$argList = @(
    '/nologo', '/target:winexe', '/platform:anycpu', '/optimize+', '/utf8output',
    ('/out:' + $out),
    ('/win32icon:' + (Join-Path $assets 'app.ico')),
    ('/win32manifest:' + (Join-Path $src 'app.manifest')),
    ('/resource:' + (Join-Path $src 'ui.xaml') + ',ui.xaml'),
    '/reference:System.dll',
    '/reference:System.Core.dll',
    '/reference:System.Xml.dll',
    '/reference:System.Xml.Linq.dll',
    ('/reference:' + (Join-Path $wpf 'WindowsBase.dll')),
    ('/reference:' + (Join-Path $wpf 'PresentationCore.dll')),
    ('/reference:' + (Join-Path $wpf 'PresentationFramework.dll')),
    ('/reference:' + (Join-Path $fw 'System.Xaml.dll')),
    (Join-Path $src 'Program.cs')
)
& $csc $argList
if ($LASTEXITCODE -ne 0) { throw "csc failed with exit code $LASTEXITCODE" }
Get-Item -LiteralPath $out | Select-Object FullName, Length, LastWriteTime
