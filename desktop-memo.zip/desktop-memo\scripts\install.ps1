#requires -Version 3.0
# Optional local helper: copy the freshly built exe to the current user's Desktop
# and launch it detached (WMI Win32_Process.Create -- reliable across sessions).
# Pure ASCII: Chinese exe stem is built from Unicode code points (PS5.1 GBK pitfall).
param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'

$root   = Split-Path -Parent $PSScriptRoot
$bin    = Join-Path $root 'bin'
$stem = ''
foreach ($c in 0x684C,0x9762,0x5907,0x5FD8,0x5F55) { $stem += [char]$c }  # 桌面备忘录
$name = $stem + '.exe'
$src  = Join-Path $bin $name
$desktop = [Environment]::GetFolderPath('Desktop')
$target  = Join-Path $desktop $name

if (-not (Test-Path -LiteralPath $src)) { throw "Build first! Not found: $src  (run scripts\build.ps1)" }

# Stop any running instance of either copy so the single-instance mutex is freed.
$procs = Get-CimInstance Win32_Process | Where-Object {
    $_.ExecutablePath -eq $target -or $_.ExecutablePath -eq $src
}
foreach ($p in $procs) {
    "STOPPID=$($p.ProcessId) PATH=$($p.ExecutablePath)"
    Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Milliseconds 500

Copy-Item -LiteralPath $src -Destination $target -Force
$fi = Get-Item -LiteralPath $target
"INSTALLED=$($fi.FullName) SIZE=$($fi.Length)"

if (-not $NoLaunch) {
    $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
        CommandLine = '"' + $target + '"'
    }
    "LAUNCH_RETURN=$($r.ReturnValue) PID=$($r.ProcessId)"
}
